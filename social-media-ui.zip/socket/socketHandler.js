import { auth } from "../config/firebase.js"
import User from "../models/User.js"
import Conversation from "../models/Conversation.js"
import Message from "../models/Message.js"

// Store active users
const activeUsers = new Map()

export const initializeSocketIO = (io) => {
  // Middleware for authentication
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token

      if (!token) {
        return next(new Error("Authentication error"))
      }

      // Verify Firebase token
      const decodedToken = await auth.verifyIdToken(token)

      if (!decodedToken) {
        return next(new Error("Invalid token"))
      }

      // Find user in database
      const user = await User.findOne({ firebaseUid: decodedToken.uid })

      if (!user) {
        return next(new Error("User not found"))
      }

      if (!user.isActive) {
        return next(new Error("Account is deactivated"))
      }

      // Attach user to socket
      socket.user = user

      next()
    } catch (error) {
      next(new Error("Authentication error"))
    }
  })

  io.on("connection", (socket) => {
    const userId = socket.user._id.toString()

    console.log(`User connected: ${userId}`)

    // Add user to active users
    activeUsers.set(userId, {
      socketId: socket.id,
      lastActive: new Date(),
      user: {
        _id: socket.user._id,
        username: socket.user.username,
        name: socket.user.name,
        profilePicture: socket.user.profilePicture,
      },
    })

    // Join user to their personal room
    socket.join(userId)

    // Join user to their conversation rooms
    joinUserConversations(socket)

    // Broadcast user online status
    broadcastUserStatus(userId, true)

    // Handle typing events
    socket.on("typing", (data) => {
      const { conversationId } = data
      socket.to(conversationId).emit("userTyping", {
        user: {
          _id: socket.user._id,
          username: socket.user.username,
        },
        conversationId,
      })
    })

    socket.on("stopTyping", (data) => {
      const { conversationId } = data
      socket.to(conversationId).emit("userStoppedTyping", {
        user: {
          _id: socket.user._id,
          username: socket.user.username,
        },
        conversationId,
      })
    })

    // Handle message read
    socket.on("messageRead", async (data) => {
      const { messageId, conversationId } = data

      try {
        const message = await Message.findById(messageId)

        if (!message) return

        // Check if user already marked as read
        const alreadyRead = message.readBy.some((read) => read.user.toString() === userId)

        if (!alreadyRead) {
          message.readBy.push({
            user: socket.user._id,
            readAt: new Date(),
          })

          await message.save()

          // Emit to conversation that message was read
          io.to(conversationId).emit("messageReadUpdate", {
            messageId,
            readBy: message.readBy,
          })

          // Update unread count for user
          await updateUnreadCount(userId, conversationId)
        }
      } catch (error) {
        console.error("Error marking message as read:", error)
      }
    })

    // Handle disconnect
    socket.on("disconnect", () => {
      console.log(`User disconnected: ${userId}`)

      // Update user's last seen
      updateUserLastSeen(userId)

      // Remove user from active users after a delay (to handle reconnects)
      setTimeout(() => {
        const userActive = activeUsers.get(userId)

        if (userActive && userActive.socketId === socket.id) {
          activeUsers.delete(userId)

          // Broadcast user offline status
          broadcastUserStatus(userId, false)
        }
      }, 10000) // 10 seconds delay
    })
  })

  // Function to join user to their conversation rooms
  async function joinUserConversations(socket) {
    try {
      const conversations = await Conversation.find({
        participants: socket.user._id,
      })

      conversations.forEach((conversation) => {
        socket.join(conversation._id.toString())
      })
    } catch (error) {
      console.error("Error joining user conversations:", error)
    }
  }

  // Function to broadcast user status
  function broadcastUserStatus(userId, isOnline) {
    io.emit("userStatus", {
      userId,
      isOnline,
      lastSeen: isOnline ? new Date() : activeUsers.get(userId)?.lastActive || new Date(),
    })
  }

  // Function to update user's last seen
  async function updateUserLastSeen(userId) {
    try {
      const user = await User.findById(userId)

      if (user) {
        user.lastSeen = new Date()
        activeUsers.get(userId).lastActive = new Date()
        await user.save()
      }
    } catch (error) {
      console.error("Error updating user last seen:", error)
    }
  }

  // Function to update unread count
  async function updateUnreadCount(userId, conversationId) {
    try {
      const conversation = await Conversation.findById(conversationId)

      if (!conversation) return

      const userUnreadIndex = conversation.unreadCounts.findIndex((item) => item.user.toString() === userId)

      if (userUnreadIndex !== -1) {
        conversation.unreadCounts[userUnreadIndex].count = 0
        await conversation.save()

        // Emit updated unread count
        io.to(userId).emit("unreadCountUpdate", {
          conversationId,
          count: 0,
        })
      }
    } catch (error) {
      console.error("Error updating unread count:", error)
    }
  }

  // Export functions to be used in controllers
  return {
    emitToUser: (userId, event, data) => {
      io.to(userId.toString()).emit(event, data)
    },

    emitToConversation: (conversationId, event, data) => {
      io.to(conversationId.toString()).emit(event, data)
    },

    emitNewMessage: async (message) => {
      try {
        const populatedMessage = await Message.findById(message._id)
          .populate("sender", "username name profilePicture")
          .populate("replyTo")

        io.to(message.conversation.toString()).emit("newMessage", populatedMessage)

        // Update conversation participants' unread counts
        const conversation = await Conversation.findById(message.conversation)

        if (conversation) {
          conversation.participants.forEach((participantId) => {
            const participantIdStr = participantId.toString()

            // Don't increment for the sender
            if (participantIdStr !== message.sender.toString()) {
              // Find participant's unread count
              const unreadIndex = conversation.unreadCounts.findIndex(
                (item) => item.user.toString() === participantIdStr,
              )

              if (unreadIndex !== -1) {
                conversation.unreadCounts[unreadIndex].count += 1
              } else {
                conversation.unreadCounts.push({
                  user: participantId,
                  count: 1,
                })
              }

              // Emit unread count update to participant
              io.to(participantIdStr).emit("unreadCountUpdate", {
                conversationId: conversation._id.toString(),
                count: unreadIndex !== -1 ? conversation.unreadCounts[unreadIndex].count + 1 : 1,
              })
            }
          })

          // Update last message
          conversation.lastMessage = message._id
          await conversation.save()

          // Emit conversation update
          io.to(conversation._id.toString()).emit("conversationUpdate", {
            _id: conversation._id,
            lastMessage: populatedMessage,
          })
        }
      } catch (error) {
        console.error("Error emitting new message:", error)
      }
    },

    getUserStatus: (userId) => {
      const isOnline = activeUsers.has(userId.toString())
      return {
        isOnline,
        lastSeen: isOnline ? new Date() : activeUsers.get(userId.toString())?.lastActive,
      }
    },

    getActiveUsers: () => {
      return Array.from(activeUsers.keys())
    },
  }
}

