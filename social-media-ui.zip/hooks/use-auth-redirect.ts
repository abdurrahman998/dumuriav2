"use client"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth"

export function useAuthRedirect(redirectTo = "/login") {
  const { status } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (status === "unauthenticated") {
      // Store the current path to redirect back after login
      sessionStorage.setItem("redirectAfterLogin", pathname)
      router.push(redirectTo)
    }
  }, [status, router, pathname, redirectTo])

  return { isAuthenticated: status === "authenticated", isLoading: status === "loading" }
}

