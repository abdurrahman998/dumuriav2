import express from "express"
import { asyncHandler } from "../utils/asyncHandler.js"
import { verifyToken, moderatorAndAbove } from "../middleware/auth.js"
import {
  createComment,
  getCommentById,
  updateComment,
  deleteComment,
  likeComment,
  unlikeComment,
  getPostComments,
  getCommentReplies,
  reportComment,
  getReportedComments,
  resolveCommentReport,
} from "../controllers/commentController.js"

const router = express.Router()

// Public routes
router.get("/post/:postId", asyncHandler(getPostComments))
router.get("/:id/replies", asyncHandler(getCommentReplies))
router.get("/:id", asyncHandler(getCommentById))

// Protected routes
router.use(verifyToken)
router.post("/post/:postId", asyncHandler(createComment))
router.put("/:id", asyncHandler(updateComment))
router.delete("/:id", asyncHandler(deleteComment))
router.post("/:id/like", asyncHandler(likeComment))
router.post("/:id/unlike", asyncHandler(unlikeComment))
router.post("/:id/report", asyncHandler(reportComment))

// Moderator routes
router.use(moderatorAndAbove)
router.get("/reported", asyncHandler(getReportedComments))
router.post("/reported/:id/resolve", asyncHandler(resolveCommentReport))

export default router

