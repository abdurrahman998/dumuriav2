import Post from "../models/Post.js"
import User from "../models/User.js"
import { ApiError } from "../utils/ApiError.js"
import { createPostSchema, updatePostSchema } from "../utils/validators.js"
import { processImage, getFileUrl, deleteFile } from "../utils/fileUpload.js"
import path from "path"

// Create a new post
export const createPost = async (req, res) => {
  // Validate request body
  const { error, value } = createPostSchema.validate(req.body)
  if (error) {
    throw new ApiError(
      400,
      "Validation Error",
      error.details.map((d) => d.message),
    )
  }

  const { content, tags, location, visibility, poll, mentions } = value

  try {
    // Create new post
    const newPost = new Post({
      user: req.user._id,
      content,
      tags,
      location,
      visibility,
      poll,
      mentions,
    })

    // Handle media uploads if files are provided
    if (req.files && req.files.length > 0) {
      const mediaPromises = req.files.map(async (file) => {
        const fileType = file.mimetype.startsWith("image/")
          ? "image"
          : file.mimetype.startsWith("video/")
            ? "video"
            : "gif"

        // Process image files
        if (fileType === "image" && file.mimetype !== "image/gif") {
          await processImage(file.path)
        }

        return {
          type: fileType,
          url: getFileUrl(file.path),
          alt: file.originalname,
        }
      })

      newPost.media = await Promise.all(mediaPromises)
    }

    // Save post
    await newPost.save()

    // Populate user data
    const populatedPost = await Post.findById(newPost._id).populate("user", "username name profilePicture")

    // Create notifications for mentioned users
    if (mentions && mentions.length > 0) {
      const mentionNotifications = mentions.map((mention) => {
        return {
          recipient: mention.user,
          sender: req.user._id,
          type: "mention",
          post: newPost._id,
          content: `${req.user.name} mentioned you in a post`,
        }
      })

      // Save notifications (in a real app, use a notification service)
      // For simplicity, we're not implementing this here
    }

    res.status(201).json({
      success: true,
      message: "Post created successfully",
      data: populatedPost,
    })
  } catch (error) {
    // Delete uploaded files if post creation fails
    if (req.files && req.files.length > 0) {
      req.files.forEach((file) => {
        deleteFile(file.path)
      })
    }

    throw new ApiError(500, "Error creating post", [error.message])
  }
}

// Delete post
export const deletePost = async (req, res) => {
  const { id } = req.params

  try {
    const post = await Post.findById(id)

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    // Check if user is the post owner or an admin
    if (post.user.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      throw new ApiError(403, "You do not have permission to delete this post")
    }

    // Delete media files from storage
    if (post.media && post.media.length > 0) {
      post.media.forEach((media) => {
        // Extract file path from URL
        const urlParts = new URL(media.url)
        const filePath = path.join(process.cwd(), urlParts.pathname)
        deleteFile(filePath)
      })
    }

    // Delete post
    await Post.findByIdAndDelete(id)

    res.status(200).json({
      success: true,
      message: "Post deleted successfully",
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error deleting post", [error.message])
  }
}

// Get post by ID
export const getPostById = async (req, res) => {
  const { id } = req.params

  try {
    const post = await Post.findById(id)
      .populate("user", "username name profilePicture")
      .populate({
        path: "comments",
        populate: {
          path: "user",
          select: "username name profilePicture",
        },
      })

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    // Check if post is private and user is not the owner
    if (post.visibility === "private" && (!req.user || post.user._id.toString() !== req.user._id.toString())) {
      throw new ApiError(403, "You do not have permission to view this post")
    }

    // Check if post is for followers only and user is not following
    if (post.visibility === "followers" && req.user) {
      const postOwner = await User.findById(post.user._id)
      const isFollowing = postOwner.followers.includes(req.user._id)

      if (!isFollowing && post.user._id.toString() !== req.user._id.toString()) {
        throw new ApiError(403, "You must follow this user to view this post")
      }
    }

    res.status(200).json({
      success: true,
      data: post,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error fetching post", [error.message])
  }
}

// Update post
export const updatePost = async (req, res) => {
  const { id } = req.params

  // Validate request body
  const { error, value } = updatePostSchema.validate(req.body)
  if (error) {
    throw new ApiError(
      400,
      "Validation Error",
      error.details.map((d) => d.message),
    )
  }

  try {
    const post = await Post.findById(id)

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    // Check if user is the post owner
    if (post.user.toString() !== req.user._id.toString()) {
      throw new ApiError(403, "You do not have permission to update this post")
    }

    // Update post fields
    Object.keys(value).forEach((key) => {
      post[key] = value[key]
    })

    // Mark as edited
    post.isEdited = true

    await post.save()

    // Populate user data
    const updatedPost = await Post.findById(id).populate("user", "username name profilePicture")

    res.status(200).json({
      success: true,
      message: "Post updated successfully",
      data: updatedPost,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error updating post", [error.message])
  }
}

// Like post
export const likePost = async (req, res) => {
  const { id } = req.params

  try {
    const post = await Post.findById(id)

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    // Check if user already liked the post
    if (post.likes.includes(req.user._id)) {
      return res.status(200).json({
        success: true,
        message: "Post already liked",
        data: post,
      })
    }

    // Add user to likes array
    post.likes.push(req.user._id)
    await post.save()

    // Create notification for post owner
    if (post.user.toString() !== req.user._id.toString()) {
      // In a real app, use a notification service
      // For simplicity, we're not implementing this here
    }

    res.status(200).json({
      success: true,
      message: "Post liked successfully",
      data: post,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error liking post", [error.message])
  }
}

// Unlike post
export const unlikePost = async (req, res) => {
  const { id } = req.params

  try {
    const post = await Post.findById(id)

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    // Check if user has liked the post
    if (!post.likes.includes(req.user._id)) {
      return res.status(200).json({
        success: true,
        message: "Post not liked",
        data: post,
      })
    }

    // Remove user from likes array
    post.likes = post.likes.filter((userId) => userId.toString() !== req.user._id.toString())

    await post.save()

    res.status(200).json({
      success: true,
      message: "Post unliked successfully",
      data: post,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error unliking post", [error.message])
  }
}

// Get feed posts
export const getFeedPosts = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query
    const skip = (page - 1) * limit

    // Get IDs of users the current user is following
    const currentUser = await User.findById(req.user._id)
    const followingIds = currentUser.following

    // Include current user's posts in feed
    const userIds = [...followingIds, req.user._id]

    // Find posts from followed users and current user
    const posts = await Post.find({
      user: { $in: userIds },
      visibility: { $in: ["public", "followers"] },
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))
      .populate("user", "username name profilePicture")
      .populate({
        path: "comments",
        options: { limit: 2, sort: { createdAt: -1 } },
        populate: {
          path: "user",
          select: "username name profilePicture",
        },
      })

    // Get total count for pagination
    const total = await Post.countDocuments({
      user: { $in: userIds },
      visibility: { $in: ["public", "followers"] },
    })

    res.status(200).json({
      success: true,
      data: {
        posts,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    throw new ApiError(500, "Error fetching feed", [error.message])
  }
}

// Get user posts
export const getUserPosts = async (req, res) => {
  const { userId } = req.params
  const { page = 1, limit = 10 } = req.query
  const skip = (page - 1) * limit

  try {
    const user = await User.findById(userId)

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    // Determine which posts to show based on visibility and relationship
    let visibilityFilter = { visibility: "public" }

    if (req.user) {
      if (req.user._id.toString() === userId) {
        // User viewing their own posts - show all
        visibilityFilter = {}
      } else if (user.followers.includes(req.user._id)) {
        // User is a follower - show public and followers-only posts
        visibilityFilter = { visibility: { $in: ["public", "followers"] } }
      }
    }

    // Find posts
    const posts = await Post.find({
      user: userId,
      ...visibilityFilter,
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))
      .populate("user", "username name profilePicture")
      .populate({
        path: "comments",
        options: { limit: 2, sort: { createdAt: -1 } },
        populate: {
          path: "user",
          select: "username name profilePicture",
        },
      })

    // Get total count for pagination
    const total = await Post.countDocuments({
      user: userId,
      ...visibilityFilter,
    })

    res.status(200).json({
      success: true,
      data: {
        posts,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error fetching user posts", [error.message])
  }
}

// Save post
export const savePost = async (req, res) => {
  const { id } = req.params

  try {
    const post = await Post.findById(id)

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    const user = await User.findById(req.user._id)

    // Check if post is already saved
    if (user.savedPosts.includes(id)) {
      return res.status(200).json({
        success: true,
        message: "Post already saved",
        data: user.savedPosts,
      })
    }

    // Add post to saved posts
    user.savedPosts.push(id)
    await user.save()

    res.status(200).json({
      success: true,
      message: "Post saved successfully",
      data: user.savedPosts,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error saving post", [error.message])
  }
}

// Unsave post
export const unsavePost = async (req, res) => {
  const { id } = req.params

  try {
    const user = await User.findById(req.user._id)

    // Check if post is saved
    if (!user.savedPosts.includes(id)) {
      return res.status(200).json({
        success: true,
        message: "Post not saved",
        data: user.savedPosts,
      })
    }

    // Remove post from saved posts
    user.savedPosts = user.savedPosts.filter((postId) => postId.toString() !== id)

    await user.save()

    res.status(200).json({
      success: true,
      message: "Post unsaved successfully",
      data: user.savedPosts,
    })
  } catch (error) {
    throw new ApiError(500, "Error unsaving post", [error.message])
  }
}

// Get saved posts
export const getSavedPosts = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query
    const skip = (page - 1) * limit

    const user = await User.findById(req.user._id)

    // Find saved posts
    const posts = await Post.find({
      _id: { $in: user.savedPosts },
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))
      .populate("user", "username name profilePicture")
      .populate({
        path: "comments",
        options: { limit: 2, sort: { createdAt: -1 } },
        populate: {
          path: "user",
          select: "username name profilePicture",
        },
      })

    // Get total count for pagination
    const total = user.savedPosts.length

    res.status(200).json({
      success: true,
      data: {
        posts,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    throw new ApiError(500, "Error fetching saved posts", [error.message])
  }
}

// Report post
export const reportPost = async (req, res) => {
  const { id } = req.params
  const { reason } = req.body

  if (!reason) {
    throw new ApiError(400, "Reason is required")
  }

  try {
    const post = await Post.findById(id)

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    // In a real app, save report to a reports collection
    // For simplicity, we're just returning success

    res.status(200).json({
      success: true,
      message: "Post reported successfully",
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error reporting post", [error.message])
  }
}

// Get reported posts (for moderators)
export const getReportedPosts = async (req, res) => {
  // In a real app, fetch from reports collection
  // For simplicity, we're returning an empty array

  res.status(200).json({
    success: true,
    data: {
      reports: [],
    },
  })
}

// Resolve report (for moderators)
export const resolveReport = async (req, res) => {
  const { id } = req.params
  const { action } = req.body

  if (!action || !["approve", "reject", "delete"].includes(action)) {
    throw new ApiError(400, "Valid action is required")
  }

  // In a real app, update report status in reports collection
  // For simplicity, we're just returning success

  res.status(200).json({
    success: true,
    message: "Report resolved successfully",
  })
}

// Search posts
export const searchPosts = async (req, res) => {
  const { q, tags, page = 1, limit = 10 } = req.query
  const skip = (page - 1) * limit

  try {
    const query = {}

    // Text search if query provided
    if (q) {
      query.$text = { $search: q }
    }

    // Filter by tags if provided
    if (tags) {
      const tagArray = tags.split(",").map((tag) => tag.trim())
      query.tags = { $in: tagArray }
    }

    // Only show public posts for non-authenticated users
    if (!req.user) {
      query.visibility = "public"
    } else {
      // For authenticated users, show public posts and followers-only posts from followed users
      const currentUser = await User.findById(req.user._id)
      query.$or = [
        { visibility: "public" },
        {
          visibility: "followers",
          user: { $in: currentUser.following },
        },
        {
          user: req.user._id,
        },
      ]
    }

    // Find posts
    const posts = await Post.find(query)
      .sort({ score: { $meta: "textScore" }, createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))
      .populate("user", "username name profilePicture")
      .populate({
        path: "comments",
        options: { limit: 2, sort: { createdAt: -1 } },
        populate: {
          path: "user",
          select: "username name profilePicture",
        },
      })

    // Get total count for pagination
    const total = await Post.countDocuments(query)

    res.status(200).json({
      success: true,
      data: {
        posts,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    throw new ApiError(500, "Error searching posts", [error.message])
  }
}

// Get trending posts
export const getTrendingPosts = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query
    const skip = (page - 1) * limit

    // Calculate trending score based on likes, comments, and recency
    // This is a simplified algorithm - in production, use a more sophisticated approach
    const trendingPosts = await Post.aggregate([
      {
        $match: {
          visibility: "public",
          createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }, // Last 7 days
        },
      },
      {
        $addFields: {
          likesCount: { $size: "$likes" },
          commentsCount: { $size: "$comments" },
          // Calculate hours since post creation
          hoursSinceCreated: {
            $divide: [{ $subtract: [new Date(), "$createdAt"] }, 1000 * 60 * 60],
          },
        },
      },
      {
        $addFields: {
          // Simple trending score formula
          trendingScore: {
            $divide: [
              { $add: ["$likesCount", { $multiply: ["$commentsCount", 2] }] },
              { $pow: [{ $add: ["$hoursSinceCreated", 2] }, 1.5] },
            ],
          },
        },
      },
      { $sort: { trendingScore: -1 } },
      { $skip: skip },
      { $limit: Number.parseInt(limit) },
    ])

    // Get post details
    const postIds = trendingPosts.map((post) => post._id)
    const posts = await Post.find({ _id: { $in: postIds } })
      .populate("user", "username name profilePicture")
      .populate({
        path: "comments",
        options: { limit: 2, sort: { createdAt: -1 } },
        populate: {
          path: "user",
          select: "username name profilePicture",
        },
      })

    // Sort posts by trending score
    posts.sort((a, b) => {
      const aScore = trendingPosts.find((p) => p._id.toString() === a._id.toString()).trendingScore
      const bScore = trendingPosts.find((p) => p._id.toString() === b._id.toString()).trendingScore
      return bScore - aScore
    })

    // Get total count for pagination
    const total = await Post.countDocuments({
      visibility: "public",
      createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) },
    })

    res.status(200).json({
      success: true,
      data: {
        posts,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    throw new ApiError(500, "Error fetching trending posts", [error.message])
  }
}

// Vote on poll
export const voteOnPoll = async (req, res) => {
  const { id, optionId } = req.params

  try {
    const post = await Post.findById(id)

    if (!post) {
      throw new ApiError(404, "Post not found")
    }

    if (!post.poll || !post.poll.options) {
      throw new ApiError(400, "Post does not have a poll")
    }

    // Check if poll has expired
    if (post.poll.expiresAt && new Date() > new Date(post.poll.expiresAt)) {
      throw new ApiError(400, "Poll has expired")
    }

    // Find the option
    const optionIndex = post.poll.options.findIndex((option) => option._id.toString() === optionId)

    if (optionIndex === -1) {
      throw new ApiError(404, "Poll option not found")
    }

    // Check if user has already voted
    const hasVoted = post.poll.options.some((option) => option.votes.includes(req.user._id))

    if (hasVoted) {
      // Remove previous vote
      post.poll.options.forEach((option) => {
        option.votes = option.votes.filter((userId) => userId.toString() !== req.user._id.toString())
      })
    }

    // Add vote to selected option
    post.poll.options[optionIndex].votes.push(req.user._id)

    await post.save()

    res.status(200).json({
      success: true,
      message: "Vote recorded successfully",
      data: post.poll,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error voting on poll", [error.message])
  }
}

