import { auth } from "../config/firebase.js"
import User from "../models/User.js"
import { ApiError } from "../utils/ApiError.js"
import { registerSchema, loginSchema } from "../utils/validators.js"
import crypto from "crypto"
import nodemailer from "nodemailer"

// Store OTPs in memory (in production, use Redis or similar)
const otpStore = new Map()

// Create a test email transporter (replace with real SMTP in production)
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.ethereal.email",
  port: Number.parseInt(process.env.SMTP_PORT || "587"),
  secure: process.env.SMTP_SECURE === "true",
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
})

// Register a new user
export const register = async (req, res) => {
  // Validate request body
  const { error, value } = registerSchema.validate(req.body)
  if (error) {
    throw new ApiError(
      400,
      "Validation Error",
      error.details.map((d) => d.message),
    )
  }

  const { username, email, name, birthday, password } = value

  // Check if user already exists
  const existingUser = await User.findOne({
    $or: [{ email }, { username }],
  })

  if (existingUser) {
    if (existingUser.email === email) {
      throw new ApiError(409, "Email already in use")
    } else {
      throw new ApiError(409, "Username already taken")
    }
  }

  try {
    // Create user in Firebase
    const userRecord = await auth.createUser({
      email,
      password,
      displayName: name,
    })

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString()
    const otpExpiry = Date.now() + 10 * 60 * 1000 // 10 minutes

    // Store OTP
    otpStore.set(email, {
      otp,
      expiry: otpExpiry,
      userData: {
        firebaseUid: userRecord.uid,
        username,
        email,
        name,
        birthday: new Date(birthday),
      },
    })

    // Send OTP email
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || '"SocialSphere" <no-reply@socialsphere.com>',
      to: email,
      subject: "Verify your SocialSphere account",
      html: `
        <h1>Welcome to SocialSphere!</h1>
        <p>Your verification code is: <strong>${otp}</strong></p>
        <p>This code will expire in 10 minutes.</p>
      `,
    })

    res.status(200).json({
      success: true,
      message: "OTP sent to email for verification",
      data: {
        email,
      },
    })
  } catch (error) {
    // If Firebase user creation fails, throw error
    throw new ApiError(500, "Error creating user", [error.message])
  }
}

// Verify OTP
export const verifyOTP = async (req, res) => {
  const { email, otp } = req.body

  if (!email || !otp) {
    throw new ApiError(400, "Email and OTP are required")
  }

  const otpData = otpStore.get(email)

  if (!otpData) {
    throw new ApiError(400, "No OTP found for this email")
  }

  if (Date.now() > otpData.expiry) {
    otpStore.delete(email)
    throw new ApiError(400, "OTP has expired")
  }

  if (otpData.otp !== otp) {
    throw new ApiError(400, "Invalid OTP")
  }

  try {
    // Create user in our database
    const newUser = new User(otpData.userData)
    await newUser.save()

    // Delete OTP from store
    otpStore.delete(email)

    // Create custom token for frontend
    const customToken = await auth.createCustomToken(newUser.firebaseUid)

    res.status(201).json({
      success: true,
      message: "User registered successfully",
      data: {
        user: {
          id: newUser._id,
          username: newUser.username,
          name: newUser.name,
          email: newUser.email,
        },
        token: customToken,
      },
    })
  } catch (error) {
    // If MongoDB user creation fails, delete Firebase user
    try {
      await auth.deleteUser(otpData.userData.firebaseUid)
    } catch (deleteError) {
      console.error("Error deleting Firebase user:", deleteError)
    }

    throw new ApiError(500, "Error creating user", [error.message])
  }
}

// Resend OTP
export const resendOTP = async (req, res) => {
  const { email } = req.body

  if (!email) {
    throw new ApiError(400, "Email is required")
  }

  const otpData = otpStore.get(email)

  if (!otpData) {
    throw new ApiError(400, "No registration in progress for this email")
  }

  // Generate new OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString()
  const otpExpiry = Date.now() + 10 * 60 * 1000 // 10 minutes

  // Update OTP store
  otpStore.set(email, {
    ...otpData,
    otp,
    expiry: otpExpiry,
  })

  // Send OTP email
  await transporter.sendMail({
    from: process.env.EMAIL_FROM || '"SocialSphere" <no-reply@socialsphere.com>',
    to: email,
    subject: "Your new verification code",
    html: `
      <h1>SocialSphere Verification</h1>
      <p>Your new verification code is: <strong>${otp}</strong></p>
      <p>This code will expire in 10 minutes.</p>
    `,
  })

  res.status(200).json({
    success: true,
    message: "New OTP sent to email",
    data: {
      email,
    },
  })
}

// Login user
export const login = async (req, res) => {
  // Validate request body
  const { error, value } = loginSchema.validate(req.body)
  if (error) {
    throw new ApiError(
      400,
      "Validation Error",
      error.details.map((d) => d.message),
    )
  }

  const { email, password } = value

  try {
    // Find user by email
    const user = await User.findOne({ email })

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    if (!user.isActive) {
      throw new ApiError(403, "Account is deactivated")
    }

    // Firebase will handle the password verification
    // We just need to get a custom token for the frontend
    const customToken = await auth.createCustomToken(user.firebaseUid)

    // Update last seen
    user.lastSeen = new Date()
    await user.save()

    res.status(200).json({
      success: true,
      message: "Login successful",
      data: {
        user: {
          id: user._id,
          username: user.username,
          name: user.name,
          email: user.email,
          profilePicture: user.profilePicture,
          role: user.role,
        },
        token: customToken,
      },
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Login failed", [error.message])
  }
}

// Logout user
export const logout = async (req, res) => {
  // Firebase handles token invalidation on client side
  // We just update the last seen time
  const user = req.user
  user.lastSeen = new Date()
  await user.save()

  res.status(200).json({
    success: true,
    message: "Logout successful",
  })
}

// Refresh token
export const refreshToken = async (req, res) => {
  const user = req.user

  try {
    // Create new custom token
    const customToken = await auth.createCustomToken(user.firebaseUid)

    res.status(200).json({
      success: true,
      message: "Token refreshed",
      data: {
        token: customToken,
      },
    })
  } catch (error) {
    throw new ApiError(500, "Error refreshing token", [error.message])
  }
}

// Forgot password
export const forgotPassword = async (req, res) => {
  const { email } = req.body

  if (!email) {
    throw new ApiError(400, "Email is required")
  }

  // Find user by email
  const user = await User.findOne({ email })

  if (!user) {
    // Don't reveal that the user doesn't exist
    return res.status(200).json({
      success: true,
      message: "If your email is registered, you will receive a password reset link",
    })
  }

  try {
    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString("hex")
    const resetTokenExpiry = Date.now() + 60 * 60 * 1000 // 1 hour

    // Store token in memory (use Redis in production)
    otpStore.set(`reset_${email}`, {
      token: resetToken,
      expiry: resetTokenExpiry,
    })

    // Create reset URL
    const resetUrl = `${process.env.CLIENT_URL}/reset-password?token=${resetToken}&email=${email}`

    // Send email
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || '"SocialSphere" <no-reply@socialsphere.com>',
      to: email,
      subject: "Reset your password",
      html: `
        <h1>Password Reset</h1>
        <p>You requested a password reset. Click the link below to reset your password:</p>
        <a href="${resetUrl}" style="padding: 10px 20px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px;">Reset Password</a>
        <p>This link will expire in 1 hour.</p>
        <p>If you didn't request this, please ignore this email.</p>
      `,
    })

    res.status(200).json({
      success: true,
      message: "If your email is registered, you will receive a password reset link",
    })
  } catch (error) {
    throw new ApiError(500, "Error sending reset email", [error.message])
  }
}

// Reset password
export const resetPassword = async (req, res) => {
  const { email, token, password } = req.body

  if (!email || !token || !password) {
    throw new ApiError(400, "Email, token and password are required")
  }

  // Validate password
  if (password.length < 8) {
    throw new ApiError(400, "Password must be at least 8 characters")
  }

  const resetData = otpStore.get(`reset_${email}`)

  if (!resetData) {
    throw new ApiError(400, "Invalid or expired reset token")
  }

  if (Date.now() > resetData.expiry) {
    otpStore.delete(`reset_${email}`)
    throw new ApiError(400, "Reset token has expired")
  }

  if (resetData.token !== token) {
    throw new ApiError(400, "Invalid reset token")
  }

  try {
    // Find user
    const user = await User.findOne({ email })

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    // Update password in Firebase
    await auth.updateUser(user.firebaseUid, {
      password,
    })

    // Delete reset token
    otpStore.delete(`reset_${email}`)

    res.status(200).json({
      success: true,
      message: "Password reset successful",
    })
  } catch (error) {
    throw new ApiError(500, "Error resetting password", [error.message])
  }
}

// Change password
export const changePassword = async (req, res) => {
  const { currentPassword, newPassword } = req.body
  const user = req.user

  if (!currentPassword || !newPassword) {
    throw new ApiError(400, "Current password and new password are required")
  }

  // Validate new password
  if (newPassword.length < 8) {
    throw new ApiError(400, "New password must be at least 8 characters")
  }

  try {
    // Firebase will handle password verification and update
    // We need to use the Firebase Admin SDK to update the password
    await auth.updateUser(user.firebaseUid, {
      password: newPassword,
    })

    res.status(200).json({
      success: true,
      message: "Password changed successfully",
    })
  } catch (error) {
    throw new ApiError(500, "Error changing password", [error.message])
  }
}

