"use client"

import { useState, useEffect } from "react"
import { PostCard } from "@/components/post/post-card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { getSavedPosts } from "@/lib/data"

export function SavedPosts() {
  const [posts, setPosts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchSavedPosts = async () => {
      setLoading(true)
      try {
        const data = await getSavedPosts()
        setPosts(data)
      } catch (error) {
        console.error("Error fetching saved posts:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchSavedPosts()
  }, [])

  if (loading) {
    return (
      <div className="space-y-4 pt-4">
        {Array.from({ length: 2 }).map((_, i) => (
          <div key={i} className="rounded-lg border p-4">
            <div className="flex items-center space-x-4">
              <Skeleton className="h-12 w-12 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-4 w-[250px]" />
                <Skeleton className="h-4 w-[200px]" />
              </div>
            </div>
            <div className="mt-4 space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-2/3" />
            </div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-4 pt-4">
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Saved</TabsTrigger>
          <TabsTrigger value="posts">Posts</TabsTrigger>
          <TabsTrigger value="media">Media</TabsTrigger>
          <TabsTrigger value="links">Links</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4 pt-4">
          {posts.length === 0 ? (
            <div className="rounded-lg border p-8 text-center">
              <p className="text-muted-foreground">No saved posts yet.</p>
              <Button className="mt-4" variant="outline" asChild>
                <a href="/feed">Browse Feed</a>
              </Button>
            </div>
          ) : (
            posts.map((post) => <PostCard key={post.id} post={post} />)
          )}
        </TabsContent>

        <TabsContent value="posts" className="space-y-4 pt-4">
          {posts.filter((post) => !post.image).length === 0 ? (
            <div className="rounded-lg border p-8 text-center">
              <p className="text-muted-foreground">No saved text posts.</p>
            </div>
          ) : (
            posts.filter((post) => !post.image).map((post) => <PostCard key={post.id} post={post} />)
          )}
        </TabsContent>

        <TabsContent value="media" className="space-y-4 pt-4">
          {posts.filter((post) => post.image).length === 0 ? (
            <div className="rounded-lg border p-8 text-center">
              <p className="text-muted-foreground">No saved media posts.</p>
            </div>
          ) : (
            posts.filter((post) => post.image).map((post) => <PostCard key={post.id} post={post} />)
          )}
        </TabsContent>

        <TabsContent value="links" className="space-y-4 pt-4">
          <div className="rounded-lg border p-8 text-center">
            <p className="text-muted-foreground">No saved links.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

