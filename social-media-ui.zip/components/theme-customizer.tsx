"use client"

import * as React from "react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer"
import { PaintbrushIcon as PaintBrush, Sun, Moon, Laptop } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"
import { useMobile } from "@/hooks/use-mobile"

interface ThemeCustomizerProps {
  className?: string
}

export function ThemeCustomizer({ className }: ThemeCustomizerProps) {
  const { theme, setTheme } = useTheme()
  const [open, setOpen] = React.useState(false)
  const [activeTab, setActiveTab] = React.useState("theme")
  const isMobile = useMobile()

  // Preset themes
  const themes = [
    {
      name: "Default",
      primaryColor: "hsl(222.2 47.4% 11.2%)",
      accentColor: "hsl(215 27.9% 16.9%)",
    },
    {
      name: "Sunset",
      primaryColor: "hsl(20 14.3% 4.1%)",
      accentColor: "hsl(15 60% 17%)",
    },
    {
      name: "Ocean",
      primaryColor: "hsl(210 20% 8%)",
      accentColor: "hsl(200 70% 15%)",
    },
    {
      name: "Forest",
      primaryColor: "hsl(120 7% 8%)",
      accentColor: "hsl(142 71% 12%)",
    },
    {
      name: "Lavender",
      primaryColor: "hsl(270 5% 9%)",
      accentColor: "hsl(267 35% 12%)",
    },
  ]

  // Accent colors
  const accentColors = [
    { name: "Slate", value: "slate" },
    { name: "Red", value: "red" },
    { name: "Orange", value: "orange" },
    { name: "Green", value: "green" },
    { name: "Blue", value: "blue" },
    { name: "Yellow", value: "yellow" },
    { name: "Violet", value: "violet" },
    { name: "Pink", value: "pink" },
  ]

  // Apply theme
  const applyTheme = (themeName: string) => {
    // In a real app, this would update CSS variables
    console.log(`Applying theme: ${themeName}`)

    // For demo purposes, we'll just change the theme mode
    if (themeName === "Default") {
      // Keep current theme mode
    } else if (themeName === "Sunset") {
      setTheme("dark")
    } else if (themeName === "Ocean") {
      setTheme("dark")
    } else if (themeName === "Forest") {
      setTheme("dark")
    } else if (themeName === "Lavender") {
      setTheme("dark")
    }
  }

  // Apply accent color
  const applyAccentColor = (color: string) => {
    // In a real app, this would update CSS variables
    console.log(`Applying accent color: ${color}`)

    // For demo purposes, we'll just log it
    document.documentElement.style.setProperty("--accent-color", color)
  }

  const ThemeContent = () => (
    <div className="space-y-4 py-2">
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2">
          <TabsTrigger value="theme">Theme</TabsTrigger>
          <TabsTrigger value="color">Accent Color</TabsTrigger>
        </TabsList>
        <TabsContent value="theme" className="space-y-4">
          <div className="mb-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-medium">Mode</h4>
              <div className="flex items-center space-x-2">
                <Button
                  variant={theme === "light" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTheme("light")}
                  className="h-8 w-8 p-0"
                >
                  <Sun className="h-4 w-4" />
                  <span className="sr-only">Light Mode</span>
                </Button>
                <Button
                  variant={theme === "dark" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTheme("dark")}
                  className="h-8 w-8 p-0"
                >
                  <Moon className="h-4 w-4" />
                  <span className="sr-only">Dark Mode</span>
                </Button>
                <Button
                  variant={theme === "system" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setTheme("system")}
                  className="h-8 w-8 p-0"
                >
                  <Laptop className="h-4 w-4" />
                  <span className="sr-only">System Mode</span>
                </Button>
              </div>
            </div>
          </div>

          <div>
            <h4 className="mb-3 text-sm font-medium">Preset Themes</h4>
            <RadioGroup defaultValue="default" className="grid grid-cols-2 gap-2">
              {themes.map((theme) => (
                <div key={theme.name}>
                  <RadioGroupItem
                    value={theme.name.toLowerCase()}
                    id={`theme-${theme.name.toLowerCase()}`}
                    className="peer sr-only"
                    onClick={() => applyTheme(theme.name)}
                  />
                  <Label
                    htmlFor={`theme-${theme.name.toLowerCase()}`}
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <div className="w-full h-10 rounded-md mb-2" style={{ background: theme.primaryColor }} />
                    <div className="text-center text-xs">{theme.name}</div>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        </TabsContent>
        <TabsContent value="color" className="space-y-4">
          <div>
            <h4 className="mb-3 text-sm font-medium">Accent Colors</h4>
            <RadioGroup defaultValue="slate" className="grid grid-cols-4 gap-2">
              {accentColors.map((color) => (
                <div key={color.name}>
                  <RadioGroupItem
                    value={color.value}
                    id={`color-${color.value}`}
                    className="peer sr-only"
                    onClick={() => applyAccentColor(color.value)}
                  />
                  <Label
                    htmlFor={`color-${color.value}`}
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-2 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <div
                      className={`w-full h-6 rounded-md mb-1 bg-${color.value}-500`}
                      style={{
                        backgroundColor:
                          color.value === "slate"
                            ? "hsl(215, 20%, 65%)"
                            : color.value === "red"
                              ? "hsl(0, 84%, 60%)"
                              : color.value === "orange"
                                ? "hsl(24, 84%, 60%)"
                                : color.value === "green"
                                  ? "hsl(142, 71%, 45%)"
                                  : color.value === "blue"
                                    ? "hsl(221, 83%, 53%)"
                                    : color.value === "yellow"
                                      ? "hsl(41, 100%, 59%)"
                                      : color.value === "violet"
                                        ? "hsl(250, 89%, 60%)"
                                        : color.value === "pink"
                                          ? "hsl(330, 81%, 60%)"
                                          : undefined,
                      }}
                    />
                    <div className="text-center text-xs">{color.name}</div>
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={setOpen}>
        <DrawerTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className={cn("rounded-full", className)}
            data-theme-customizer-trigger="true"
          >
            <PaintBrush className="h-5 w-5" />
            <span className="sr-only">Customize theme</span>
          </Button>
        </DrawerTrigger>
        <DrawerContent>
          <DrawerHeader>
            <DrawerTitle>Customize Theme</DrawerTitle>
            <DrawerDescription>Personalize your experience with themes and colors</DrawerDescription>
          </DrawerHeader>
          <div className="px-4 pb-4">
            <ThemeContent />
          </div>
        </DrawerContent>
      </Drawer>
    )
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className={cn("rounded-full", className)}
          data-theme-customizer-trigger="true"
        >
          <PaintBrush className="h-5 w-5" />
          <span className="sr-only">Customize theme</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Customize Theme</DialogTitle>
          <DialogDescription>Personalize your experience with themes and colors</DialogDescription>
        </DialogHeader>
        <ThemeContent />
      </DialogContent>
    </Dialog>
  )
}

