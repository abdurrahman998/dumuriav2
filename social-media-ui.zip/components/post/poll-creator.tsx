"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash } from "lucide-react"

interface PollCreatorProps {
  onCreatePoll: (options: string[], duration: string) => void
  initialOptions?: string[]
  initialDuration?: string
}

export function PollCreator({ onCreatePoll, initialOptions = ["", ""], initialDuration = "1d" }: PollCreatorProps) {
  const [options, setOptions] = useState<string[]>(initialOptions)
  const [duration, setDuration] = useState(initialDuration)

  const addOption = () => {
    if (options.length < 4) {
      setOptions([...options, ""])
    }
  }

  const removeOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index))
    }
  }

  const updateOption = (index: number, value: string) => {
    const newOptions = [...options]
    newOptions[index] = value
    setOptions(newOptions)
  }

  const handleCreatePoll = () => {
    // Filter out empty options
    const validOptions = options.filter((option) => option.trim() !== "")

    if (validOptions.length >= 2) {
      onCreatePoll(validOptions, duration)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create a Poll</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Poll Options</Label>
          {options.map((option, index) => (
            <div key={index} className="flex items-center space-x-2">
              <Input
                placeholder={`Option ${index + 1}`}
                value={option}
                onChange={(e) => updateOption(index, e.target.value)}
              />
              {options.length > 2 && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeOption(index)}
                  className="h-8 w-8 rounded-full"
                >
                  <Trash className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}

          {options.length < 4 && (
            <Button variant="outline" size="sm" onClick={addOption} className="mt-2">
              <Plus className="mr-1 h-4 w-4" />
              Add Option
            </Button>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="poll-duration">Poll Duration</Label>
          <Select value={duration} onValueChange={setDuration}>
            <SelectTrigger id="poll-duration">
              <SelectValue placeholder="Select duration" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">1 hour</SelectItem>
              <SelectItem value="6h">6 hours</SelectItem>
              <SelectItem value="12h">12 hours</SelectItem>
              <SelectItem value="1d">1 day</SelectItem>
              <SelectItem value="3d">3 days</SelectItem>
              <SelectItem value="7d">7 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleCreatePoll} disabled={options.filter((option) => option.trim() !== "").length < 2}>
          Create Poll
        </Button>
      </CardFooter>
    </Card>
  )
}

