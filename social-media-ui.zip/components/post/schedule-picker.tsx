"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

interface SchedulePickerProps {
  onScheduleSelect: (date: Date) => void
}

export function SchedulePicker({ onScheduleSelect }: SchedulePickerProps) {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [hour, setHour] = useState("12")
  const [minute, setMinute] = useState("00")
  const [period, setPeriod] = useState<"AM" | "PM">("PM")

  const hours = Array.from({ length: 12 }, (_, i) => (i + 1).toString().padStart(2, "0"))
  const minutes = Array.from({ length: 60 }, (_, i) => i.toString().padStart(2, "0"))

  const handleSchedule = () => {
    if (!date) return

    const scheduledDate = new Date(date)
    let hourValue = Number.parseInt(hour)

    // Convert to 24-hour format
    if (period === "PM" && hourValue !== 12) {
      hourValue += 12
    } else if (period === "AM" && hourValue === 12) {
      hourValue = 0
    }

    scheduledDate.setHours(hourValue, Number.parseInt(minute), 0)
    onScheduleSelect(scheduledDate)
  }

  return (
    <Card className="w-80">
      <CardHeader>
        <CardTitle>Schedule Post</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            initialFocus
            disabled={(date) => date < new Date()}
          />
        </div>

        <div className="grid grid-cols-4 gap-2">
          <div className="space-y-1">
            <Label htmlFor="hour">Hour</Label>
            <Select value={hour} onValueChange={setHour}>
              <SelectTrigger id="hour">
                <SelectValue placeholder="Hour" />
              </SelectTrigger>
              <SelectContent>
                {hours.map((h) => (
                  <SelectItem key={h} value={h}>
                    {h}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <Label htmlFor="minute">Minute</Label>
            <Select value={minute} onValueChange={setMinute}>
              <SelectTrigger id="minute">
                <SelectValue placeholder="Minute" />
              </SelectTrigger>
              <SelectContent>
                {minutes.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <Label htmlFor="period">AM/PM</Label>
            <Select value={period} onValueChange={(value) => setPeriod(value as "AM" | "PM")}>
              <SelectTrigger id="period">
                <SelectValue placeholder="AM/PM" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AM">AM</SelectItem>
                <SelectItem value="PM">PM</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSchedule} disabled={!date}>
          Schedule
        </Button>
      </CardFooter>
    </Card>
  )
}

