"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, Loader2 } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface GifPickerProps {
  onGifSelect: (gifUrl: string) => void
}

export function GifPicker({ onGifSelect }: GifPickerProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [gifs, setGifs] = useState<string[]>([])
  const [trendingGifs, setTrendingGifs] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  // Mock GIF data
  const mockGifs = [
    "/placeholder.svg?height=200&width=300",
    "/placeholder.svg?height=200&width=300",
    "/placeholder.svg?height=200&width=300",
    "/placeholder.svg?height=200&width=300",
    "/placeholder.svg?height=200&width=300",
    "/placeholder.svg?height=200&width=300",
  ]

  useEffect(() => {
    // Simulate loading trending GIFs
    setIsLoading(true)
    setTimeout(() => {
      setTrendingGifs(mockGifs)
      setIsLoading(false)
    }, 500)
  }, [])

  const handleSearch = () => {
    if (!searchQuery.trim()) return

    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      setGifs(mockGifs)
      setIsLoading(false)
    }, 500)
  }

  return (
    <Card className="w-80 max-w-[90vw]">
      <CardHeader className="p-3">
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search GIFs"
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
          </div>
          <Button size="sm" onClick={handleSearch}>
            Search
          </Button>
        </div>
      </CardHeader>
      <Tabs defaultValue="trending">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="search" disabled={!searchQuery}>
            Search Results
          </TabsTrigger>
        </TabsList>
        <TabsContent value="trending">
          <CardContent className="p-3">
            {isLoading ? (
              <div className="flex h-40 items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {trendingGifs.map((gif, index) => (
                  <button
                    key={index}
                    className="overflow-hidden rounded-md hover:opacity-80"
                    onClick={() => onGifSelect(gif)}
                  >
                    <img
                      src={gif || "/placeholder.svg"}
                      alt={`Trending GIF ${index + 1}`}
                      className="h-auto w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </TabsContent>
        <TabsContent value="search">
          <CardContent className="p-3">
            {isLoading ? (
              <div className="flex h-40 items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : gifs.length > 0 ? (
              <div className="grid grid-cols-2 gap-2">
                {gifs.map((gif, index) => (
                  <button
                    key={index}
                    className="overflow-hidden rounded-md hover:opacity-80"
                    onClick={() => onGifSelect(gif)}
                  >
                    <img
                      src={gif || "/placeholder.svg"}
                      alt={`GIF ${index + 1}`}
                      className="h-auto w-full object-cover"
                    />
                  </button>
                ))}
              </div>
            ) : (
              <div className="flex h-40 items-center justify-center text-center text-muted-foreground">
                <p>No GIFs found. Try a different search term.</p>
              </div>
            )}
          </CardContent>
        </TabsContent>
      </Tabs>
    </Card>
  )
}

