"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { X } from "lucide-react"

interface BackgroundPickerProps {
  onBackgroundSelect: (background: string) => void
}

export function BackgroundPicker({ onBackgroundSelect }: BackgroundPickerProps) {
  // Background color options
  const backgrounds = [
    { color: "#ffffff", name: "None" },
    { color: "#f87171", name: "Red" },
    { color: "#fb923c", name: "Orange" },
    { color: "#facc15", name: "Yellow" },
    { color: "#4ade80", name: "Green" },
    { color: "#60a5fa", name: "Blue" },
    { color: "#a78bfa", name: "Purple" },
    { color: "#f472b6", name: "Pink" },
    { color: "#94a3b8", name: "Gray" },
  ]

  return (
    <Card className="w-64">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm">Choose Background</CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div className="grid grid-cols-3 gap-2">
          <Button
            variant="outline"
            className="flex h-12 w-full items-center justify-center rounded-md border-dashed"
            onClick={() => onBackgroundSelect("")}
          >
            <X className="h-6 w-6" />
          </Button>

          {backgrounds.slice(1).map((bg, index) => (
            <button
              key={index}
              className="h-12 w-full rounded-md border transition-transform hover:scale-105"
              style={{ backgroundColor: bg.color }}
              onClick={() => onBackgroundSelect(bg.color)}
              title={bg.name}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

