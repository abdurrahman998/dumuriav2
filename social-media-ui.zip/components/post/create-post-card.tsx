"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Image,
  Smile,
  MapPin,
  Calendar,
  X,
  Video,
  FileText,
  BarChart2,
  AtSign,
  Hash,
  Globe,
  Users,
  Lock,
  Clock,
  Save,
  Palette,
  Eye,
  GiftIcon as Gif,
  Music,
  ChevronDown,
  Plus,
  Check,
} from "lucide-react"
import { Icons } from "@/components/icons"
import { EmojiPicker } from "@/components/post/emoji-picker"
import { PollCreator } from "@/components/post/poll-creator"
import { GifPicker } from "@/components/post/gif-picker"
import { LocationPicker } from "@/components/post/location-picker"
import { SchedulePicker } from "@/components/post/schedule-picker"
import { BackgroundPicker } from "@/components/post/background-picker"
import { TagPeople } from "@/components/post/tag-people"
import { PostPreview } from "@/components/post/post-preview"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"

export function CreatePostCard() {
  const [content, setContent] = useState("")
  const [selectedImages, setSelectedImages] = useState<string[]>([])
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null)
  const [selectedGif, setSelectedGif] = useState<string | null>(null)
  const [selectedAudio, setSelectedAudio] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const [showGifPicker, setShowGifPicker] = useState(false)
  const [showPollCreator, setShowPollCreator] = useState(false)
  const [showLocationPicker, setShowLocationPicker] = useState(false)
  const [showSchedulePicker, setShowSchedulePicker] = useState(false)
  const [showBackgroundPicker, setShowBackgroundPicker] = useState(false)
  const [showTagPeople, setShowTagPeople] = useState(false)
  const [showPreview, setShowPreview] = useState(false)
  const [location, setLocation] = useState<string | null>(null)
  const [scheduledTime, setScheduledTime] = useState<Date | null>(null)
  const [background, setBackground] = useState<string | null>(null)
  const [taggedPeople, setTaggedPeople] = useState<string[]>([])
  const [visibility, setVisibility] = useState<"public" | "friends" | "private">("public")
  const [feeling, setFeeling] = useState<string | null>(null)
  const [pollOptions, setPollOptions] = useState<string[]>([])
  const [pollDuration, setPollDuration] = useState<string>("1d")
  const [activeTab, setActiveTab] = useState<string>("post")
  const [isDraft, setIsDraft] = useState(false)
  const [characterCount, setCharacterCount] = useState(0)
  const [hashtags, setHashtags] = useState<string[]>([])
  const [mentions, setMentions] = useState<string[]>([])
  const [showFormatting, setShowFormatting] = useState(false)

  const imageInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const audioInputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const MAX_CHAR_COUNT = 500

  useEffect(() => {
    // Extract hashtags and mentions from content
    const extractedHashtags = content.match(/#[\w]+/g) || []
    const extractedMentions = content.match(/@[\w]+/g) || []

    setHashtags(extractedHashtags.map((tag) => tag.substring(1)))
    setMentions(extractedMentions.map((mention) => mention.substring(1)))

    // Update character count
    setCharacterCount(content.length)
  }, [content])

  // Load draft from local storage
  useEffect(() => {
    const savedDraft = localStorage.getItem("postDraft")
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft)
        setContent(draft.content || "")
        setSelectedImages(draft.images || [])
        setSelectedVideo(draft.video || null)
        setSelectedGif(draft.gif || null)
        setSelectedAudio(draft.audio || null)
        setLocation(draft.location || null)
        setScheduledTime(draft.scheduledTime ? new Date(draft.scheduledTime) : null)
        setBackground(draft.background || null)
        setTaggedPeople(draft.taggedPeople || [])
        setVisibility(draft.visibility || "public")
        setFeeling(draft.feeling || null)
        setPollOptions(draft.pollOptions || [])
        setPollDuration(draft.pollDuration || "1d")
        setIsDraft(true)
      } catch (error) {
        console.error("Error loading draft:", error)
      }
    }
  }, [])

  const saveDraft = () => {
    const draft = {
      content,
      images: selectedImages,
      video: selectedVideo,
      gif: selectedGif,
      audio: selectedAudio,
      location,
      scheduledTime: scheduledTime?.toISOString(),
      background,
      taggedPeople,
      visibility,
      feeling,
      pollOptions,
      pollDuration,
    }

    localStorage.setItem("postDraft", JSON.stringify(draft))
    setIsDraft(true)

    // Show toast notification
    alert("Draft saved successfully!")
  }

  const clearDraft = () => {
    localStorage.removeItem("postDraft")
    setIsDraft(false)
  }

  const handleImageClick = () => {
    imageInputRef.current?.click()
  }

  const handleVideoClick = () => {
    videoInputRef.current?.click()
  }

  const handleAudioClick = () => {
    audioInputRef.current?.click()
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newImages: string[] = []

      Array.from(files).forEach((file) => {
        const reader = new FileReader()
        reader.onload = (event) => {
          if (event.target?.result) {
            newImages.push(event.target.result as string)
            if (newImages.length === files.length) {
              setSelectedImages((prev) => [...prev, ...newImages])
            }
          }
        }
        reader.readAsDataURL(file)
      })
    }
  }

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setSelectedVideo(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleAudioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        setSelectedAudio(event.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeImage = (index: number) => {
    setSelectedImages((prev) => prev.filter((_, i) => i !== index))
  }

  const removeVideo = () => {
    setSelectedVideo(null)
    if (videoInputRef.current) {
      videoInputRef.current.value = ""
    }
  }

  const removeAudio = () => {
    setSelectedAudio(null)
    if (audioInputRef.current) {
      audioInputRef.current.value = ""
    }
  }

  const removeGif = () => {
    setSelectedGif(null)
  }

  const handleEmojiSelect = (emoji: string) => {
    if (textareaRef.current) {
      const start = textareaRef.current.selectionStart
      const end = textareaRef.current.selectionEnd

      const newContent = content.substring(0, start) + emoji + content.substring(end)
      setContent(newContent)

      // Set cursor position after the inserted emoji
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = start + emoji.length
          textareaRef.current.selectionEnd = start + emoji.length
          textareaRef.current.focus()
        }
      }, 0)
    } else {
      setContent((prev) => prev + emoji)
    }

    setShowEmojiPicker(false)
  }

  const handleGifSelect = (gifUrl: string) => {
    setSelectedGif(gifUrl)
    setShowGifPicker(false)
  }

  const handleLocationSelect = (selectedLocation: string) => {
    setLocation(selectedLocation)
    setShowLocationPicker(false)
  }

  const handleScheduleSelect = (date: Date) => {
    setScheduledTime(date)
    setShowSchedulePicker(false)
  }

  const handleBackgroundSelect = (bgColor: string) => {
    setBackground(bgColor)
    setShowBackgroundPicker(false)
  }

  const handleTagPeopleSelect = (people: string[]) => {
    setTaggedPeople(people)
    setShowTagPeople(false)
  }

  const handlePollCreate = (options: string[], duration: string) => {
    setPollOptions(options)
    setPollDuration(duration)
    setShowPollCreator(false)
  }

  const handleFeelingSelect = (selectedFeeling: string) => {
    setFeeling(selectedFeeling)
  }

  const handleFormatText = (format: string) => {
    if (!textareaRef.current) return

    const start = textareaRef.current.selectionStart
    const end = textareaRef.current.selectionEnd
    const selectedText = content.substring(start, end)

    let formattedText = ""
    let cursorOffset = 0

    switch (format) {
      case "bold":
        formattedText = `**${selectedText}**`
        cursorOffset = 2
        break
      case "italic":
        formattedText = `*${selectedText}*`
        cursorOffset = 1
        break
      case "code":
        formattedText = `\`${selectedText}\``
        cursorOffset = 1
        break
      case "link":
        formattedText = `[${selectedText}](url)`
        cursorOffset = 1
        break
      case "h1":
        formattedText = `# ${selectedText}`
        cursorOffset = 2
        break
      case "h2":
        formattedText = `## ${selectedText}`
        cursorOffset = 3
        break
      case "list":
        formattedText = `- ${selectedText}`
        cursorOffset = 2
        break
      default:
        return
    }

    const newContent = content.substring(0, start) + formattedText + content.substring(end)
    setContent(newContent)

    // Set cursor position after the formatting
    setTimeout(() => {
      if (textareaRef.current) {
        if (selectedText.length > 0) {
          textareaRef.current.selectionStart = start + formattedText.length
          textareaRef.current.selectionEnd = start + formattedText.length
        } else {
          textareaRef.current.selectionStart = start + cursorOffset
          textareaRef.current.selectionEnd = start + cursorOffset
        }
        textareaRef.current.focus()
      }
    }, 0)
  }

  const handleSubmit = async () => {
    if (
      (!content.trim() &&
        !selectedImages.length &&
        !selectedVideo &&
        !selectedGif &&
        !selectedAudio &&
        !pollOptions.length) ||
      isSubmitting
    )
      return

    setIsSubmitting(true)

    // Prepare post data
    const postData = {
      content,
      images: selectedImages,
      video: selectedVideo,
      gif: selectedGif,
      audio: selectedAudio,
      location,
      scheduledTime,
      background,
      taggedPeople,
      visibility,
      feeling,
      pollOptions: pollOptions.length > 0 ? { options: pollOptions, duration: pollDuration } : null,
      hashtags,
      mentions,
    }

    // Simulate API call
    setTimeout(() => {
      console.log("Post data:", postData)

      // Reset form
      setContent("")
      setSelectedImages([])
      setSelectedVideo(null)
      setSelectedGif(null)
      setSelectedAudio(null)
      setLocation(null)
      setScheduledTime(null)
      setBackground(null)
      setTaggedPeople([])
      setFeeling(null)
      setPollOptions([])
      setPollDuration("1d")
      setIsSubmitting(false)

      // Clear draft if exists
      clearDraft()

      // In a real app, we would refresh the feed or add the new post to the feed
    }, 1500)
  }

  const getVisibilityIcon = () => {
    switch (visibility) {
      case "public":
        return <Globe className="h-4 w-4" />
      case "friends":
        return <Users className="h-4 w-4" />
      case "private":
        return <Lock className="h-4 w-4" />
    }
  }

  const getVisibilityText = () => {
    switch (visibility) {
      case "public":
        return "Public"
      case "friends":
        return "Friends"
      case "private":
        return "Only me"
    }
  }

  const hasContent =
    content.trim().length > 0 ||
    selectedImages.length > 0 ||
    selectedVideo !== null ||
    selectedGif !== null ||
    selectedAudio !== null ||
    pollOptions.length > 0

  const isOverCharLimit = characterCount > MAX_CHAR_COUNT

  return (
    <Card className={cn("relative overflow-hidden transition-all", background && "border-0")}>
      {background && <div className="absolute inset-0 z-0 opacity-20" style={{ backgroundColor: background }} />}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="relative z-10">
        <TabsList className="w-full rounded-none border-b bg-transparent p-0">
          <TabsTrigger
            value="post"
            className="flex-1 rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary"
          >
            Create Post
          </TabsTrigger>
          <TabsTrigger
            value="poll"
            className="flex-1 rounded-none border-b-2 border-transparent px-4 py-2 data-[state=active]:border-primary"
            onClick={() => setShowPollCreator(true)}
          >
            Create Poll
          </TabsTrigger>
        </TabsList>

        <TabsContent value="post" className="pt-4">
          <CardContent className="p-4">
            <div className="flex space-x-4">
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=40&width=40" alt="@user" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">John Doe</span>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 gap-1 text-muted-foreground">
                        {getVisibilityIcon()}
                        <span>{getVisibilityText()}</span>
                        <ChevronDown className="h-3 w-3 opacity-50" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="start">
                      <DropdownMenuItem onClick={() => setVisibility("public")}>
                        <Globe className="mr-2 h-4 w-4" />
                        <span>Public</span>
                        {visibility === "public" && <Check className="ml-auto h-4 w-4" />}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setVisibility("friends")}>
                        <Users className="mr-2 h-4 w-4" />
                        <span>Friends</span>
                        {visibility === "friends" && <Check className="ml-auto h-4 w-4" />}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setVisibility("private")}>
                        <Lock className="mr-2 h-4 w-4" />
                        <span>Only me</span>
                        {visibility === "private" && <Check className="ml-auto h-4 w-4" />}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="flex flex-wrap gap-2">
                  {feeling && (
                    <div className="flex items-center text-sm text-muted-foreground rounded-full bg-muted px-3 py-1">
                      <span>feeling {feeling}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="ml-1 h-5 w-5 p-0 rounded-full"
                        onClick={() => setFeeling(null)}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove feeling</span>
                      </Button>
                    </div>
                  )}

                  {location && (
                    <div className="flex items-center text-sm text-muted-foreground rounded-full bg-muted px-3 py-1">
                      <MapPin className="mr-1 h-3 w-3" />
                      <span>{location}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="ml-1 h-5 w-5 p-0 rounded-full"
                        onClick={() => setLocation(null)}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove location</span>
                      </Button>
                    </div>
                  )}

                  {scheduledTime && (
                    <div className="flex items-center text-sm text-muted-foreground rounded-full bg-muted px-3 py-1">
                      <Clock className="mr-1 h-3 w-3" />
                      <span>Scheduled for {scheduledTime.toLocaleString()}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="ml-1 h-5 w-5 p-0 rounded-full"
                        onClick={() => setScheduledTime(null)}
                      >
                        <X className="h-3 w-3" />
                        <span className="sr-only">Remove schedule</span>
                      </Button>
                    </div>
                  )}
                </div>

                <div className="relative">
                  <Textarea
                    ref={textareaRef}
                    placeholder="What's happening?"
                    className={cn(
                      "min-h-[120px] resize-none border-0 p-0 focus-visible:ring-0",
                      background && "bg-transparent",
                    )}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    maxLength={MAX_CHAR_COUNT + 50} // Allow some buffer over the limit
                  />

                  {showFormatting && (
                    <div className="absolute bottom-0 left-0 right-0 flex items-center justify-start space-x-1 border-t bg-background p-2">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleFormatText("bold")}
                            >
                              <span className="font-bold">B</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Bold</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleFormatText("italic")}
                            >
                              <span className="italic">I</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Italic</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleFormatText("code")}
                            >
                              <code>{"<>"}</code>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Code</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleFormatText("link")}
                            >
                              <span className="underline">Link</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Link</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleFormatText("h1")}
                            >
                              <span className="text-lg font-bold">H1</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Heading 1</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleFormatText("h2")}
                            >
                              <span className="text-base font-bold">H2</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Heading 2</TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 rounded-full"
                              onClick={() => handleFormatText("list")}
                            >
                              <span className="font-bold">• List</span>
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>List</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  )}
                </div>

                {/* Character counter */}
                <div
                  className={cn("flex justify-end text-xs", isOverCharLimit ? "text-red-500" : "text-muted-foreground")}
                >
                  {characterCount}/{MAX_CHAR_COUNT}
                </div>

                {/* Media preview section */}
                <div className="space-y-4">
                  {/* Images preview */}
                  {selectedImages.length > 0 && (
                    <div className="rounded-lg border p-3 space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium">Images</h4>
                      </div>
                      <div
                        className={cn(
                          "grid gap-2",
                          selectedImages.length === 1
                            ? "grid-cols-1"
                            : selectedImages.length === 2
                              ? "grid-cols-2"
                              : selectedImages.length === 3
                                ? "grid-cols-2"
                                : "grid-cols-2",
                        )}
                      >
                        {selectedImages.map((image, index) => (
                          <div key={index} className="relative rounded-lg overflow-hidden">
                            <img
                              src={image || "/placeholder.svg"}
                              alt={`Selected ${index + 1}`}
                              className="w-full h-auto object-cover"
                              style={{ maxHeight: "300px" }}
                            />
                            <Button
                              variant="secondary"
                              size="icon"
                              className="absolute right-2 top-2 h-8 w-8 rounded-full bg-background/80 backdrop-blur"
                              onClick={() => removeImage(index)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Video preview */}
                  {selectedVideo && (
                    <div className="rounded-lg border p-3 space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium">Video</h4>
                      </div>
                      <div className="relative rounded-lg overflow-hidden">
                        <video src={selectedVideo} controls className="w-full h-auto" style={{ maxHeight: "300px" }} />
                        <Button
                          variant="secondary"
                          size="icon"
                          className="absolute right-2 top-2 h-8 w-8 rounded-full bg-background/80 backdrop-blur"
                          onClick={removeVideo}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* GIF preview */}
                  {selectedGif && (
                    <div className="rounded-lg border p-3 space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium">GIF</h4>
                      </div>
                      <div className="relative rounded-lg overflow-hidden">
                        <img
                          src={selectedGif || "/placeholder.svg"}
                          alt="Selected GIF"
                          className="w-full h-auto object-cover"
                          style={{ maxHeight: "300px" }}
                        />
                        <Button
                          variant="secondary"
                          size="icon"
                          className="absolute right-2 top-2 h-8 w-8 rounded-full bg-background/80 backdrop-blur"
                          onClick={removeGif}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Audio preview */}
                  {selectedAudio && (
                    <div className="rounded-lg border p-3 space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium">Audio</h4>
                      </div>
                      <div className="relative rounded-lg overflow-hidden bg-muted p-3">
                        <audio src={selectedAudio} controls className="w-full" />
                        <Button
                          variant="secondary"
                          size="icon"
                          className="absolute right-2 top-2 h-8 w-8 rounded-full bg-background/80 backdrop-blur"
                          onClick={removeAudio}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Poll preview */}
                  {pollOptions.length > 0 && (
                    <div className="rounded-lg border p-3 space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium">Poll</h4>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="mr-1 h-3 w-3" />
                          <span>Duration: {pollDuration}</span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {pollOptions.map((option, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <div className="h-4 w-4 rounded-full border border-primary"></div>
                            <span>{option}</span>
                          </div>
                        ))}
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="mt-2 text-red-500 hover:text-red-600"
                        onClick={() => {
                          setPollOptions([])
                          setPollDuration("1d")
                        }}
                      >
                        <X className="mr-1 h-4 w-4" />
                        Remove poll
                      </Button>
                    </div>
                  )}

                  {/* Tagged people preview */}
                  {taggedPeople.length > 0 && (
                    <div className="rounded-lg border p-3 space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium">Tagged People</h4>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {taggedPeople.map((person, index) => (
                          <div key={index} className="flex items-center rounded-full bg-muted px-2 py-1 text-xs">
                            <AtSign className="mr-1 h-3 w-3" />
                            <span>{person}</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="ml-1 h-4 w-4 p-0 rounded-full"
                              onClick={() => setTaggedPeople((prev) => prev.filter((_, i) => i !== index))}
                            >
                              <X className="h-2 w-2" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Hashtags preview */}
                  {hashtags.length > 0 && (
                    <div className="rounded-lg border p-3 space-y-2">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="text-sm font-medium">Hashtags</h4>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {hashtags.map((tag, index) => (
                          <div key={index} className="flex items-center rounded-full bg-muted px-2 py-1 text-xs">
                            <Hash className="mr-1 h-3 w-3" />
                            <span>{tag}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>

          <CardFooter className="flex flex-col space-y-4 px-4 pb-4">
            <div className="flex flex-wrap items-center gap-3 border-t pt-3">
              <div className="flex flex-wrap items-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={handleImageClick}
                      >
                        <Image className="h-5 w-5" />
                        <span className="sr-only">Add image</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Add image</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={handleVideoClick}
                      >
                        <Video className="h-5 w-5" />
                        <span className="sr-only">Add video</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Add video</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={handleAudioClick}
                      >
                        <Music className="h-5 w-5" />
                        <span className="sr-only">Add audio</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Add audio</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowGifPicker(!showGifPicker)}
                      >
                        <Gif className="h-5 w-5" />
                        <span className="sr-only">Add GIF</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Add GIF</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              <div className="h-6 border-l mx-1"></div>

              <div className="flex flex-wrap items-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                      >
                        <Smile className="h-5 w-5" />
                        <span className="sr-only">Add emoji</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Add emoji</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowPollCreator(!showPollCreator)}
                      >
                        <BarChart2 className="h-5 w-5" />
                        <span className="sr-only">Create poll</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Create poll</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              <div className="h-6 border-l mx-1"></div>

              <div className="flex flex-wrap items-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowLocationPicker(!showLocationPicker)}
                      >
                        <MapPin className="h-5 w-5" />
                        <span className="sr-only">Add location</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Add location</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger as Child>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowSchedulePicker(!showSchedulePicker)}
                      >
                        <Calendar className="h-5 w-5" />
                        <span className="sr-only">Schedule post</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Schedule post</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowTagPeople(!showTagPeople)}
                      >
                        <AtSign className="h-5 w-5" />
                        <span className="sr-only">Tag people</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Tag people</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              <div className="h-6 border-l mx-1"></div>

              <div className="flex flex-wrap items-center gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowBackgroundPicker(!showBackgroundPicker)}
                      >
                        <Palette className="h-5 w-5" />
                        <span className="sr-only">Add background</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Add background</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowFormatting(!showFormatting)}
                      >
                        <FileText className="h-5 w-5" />
                        <span className="sr-only">Text formatting</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Text formatting</TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="rounded-full text-blue-500 h-9 w-9 p-0"
                        onClick={() => setShowPreview(!showPreview)}
                      >
                        <Eye className="h-5 w-5" />
                        <span className="sr-only">Preview post</span>
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>Preview post</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </div>

              <div className="h-6 border-l mx-1"></div>

              <div className="flex flex-wrap items-center gap-2">
                <TooltipProvider>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="rounded-full text-blue-500 h-9 w-9 p-0">
                        <Plus className="h-5 w-5" />
                        <span className="sr-only">More options</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleFeelingSelect("happy")}>
                        <Smile className="mr-2 h-4 w-4" />
                        <span>Feeling happy</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleFeelingSelect("sad")}>
                        <span className="mr-2">😢</span>
                        <span>Feeling sad</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleFeelingSelect("excited")}>
                        <span className="mr-2">🎉</span>
                        <span>Feeling excited</span>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => {
                          setContent((prev) => prev + " #")
                          if (textareaRef.current) {
                            textareaRef.current.focus()
                          }
                        }}
                      >
                        <Hash className="mr-2 h-4 w-4" />
                        <span>Add hashtag</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          setContent((prev) => prev + " @")
                          if (textareaRef.current) {
                            textareaRef.current.focus()
                          }
                        }}
                      >
                        <AtSign className="mr-2 h-4 w-4" />
                        <span>Mention someone</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TooltipProvider>
              </div>

              <input
                type="file"
                ref={imageInputRef}
                className="hidden"
                accept="image/*"
                multiple
                onChange={handleImageChange}
              />
              <input type="file" ref={videoInputRef} className="hidden" accept="video/*" onChange={handleVideoChange} />
              <input type="file" ref={audioInputRef} className="hidden" accept="audio/*" onChange={handleAudioChange} />
            </div>

            <div className="flex w-full items-center justify-between border-t pt-3">
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={saveDraft} disabled={!hasContent}>
                  <Save className="mr-1 h-4 w-4" />
                  Save draft
                </Button>

                {isDraft && (
                  <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600" onClick={clearDraft}>
                    <X className="mr-1 h-4 w-4" />
                    Clear draft
                  </Button>
                )}
              </div>

              <Button
                onClick={handleSubmit}
                disabled={!hasContent || isSubmitting || isOverCharLimit}
                className="ml-auto"
              >
                {isSubmitting && <Icons.spinner className="mr-2 h-4 w-4 animate-spin" />}
                {scheduledTime ? "Schedule" : "Post"}
              </Button>
            </div>
          </CardFooter>
        </TabsContent>

        <TabsContent value="poll" className="pt-4">
          {showPollCreator && (
            <PollCreator onCreatePoll={handlePollCreate} initialOptions={pollOptions} initialDuration={pollDuration} />
          )}
        </TabsContent>
      </Tabs>

      {/* Emoji Picker */}
      {showEmojiPicker && (
        <div className="absolute right-0 top-full z-50 mt-2">
          <EmojiPicker onEmojiSelect={handleEmojiSelect} />
        </div>
      )}

      {/* GIF Picker */}
      {showGifPicker && (
        <div className="absolute right-0 top-full z-50 mt-2">
          <GifPicker onGifSelect={handleGifSelect} />
        </div>
      )}

      {/* Location Picker */}
      {showLocationPicker && (
        <div className="absolute right-0 top-full z-50 mt-2">
          <LocationPicker onLocationSelect={handleLocationSelect} />
        </div>
      )}

      {/* Schedule Picker */}
      {showSchedulePicker && (
        <div className="absolute right-0 top-full z-50 mt-2">
          <SchedulePicker onScheduleSelect={handleScheduleSelect} />
        </div>
      )}

      {/* Background Picker */}
      {showBackgroundPicker && (
        <div className="absolute right-0 top-full z-50 mt-2">
          <BackgroundPicker onBackgroundSelect={handleBackgroundSelect} />
        </div>
      )}

      {/* Tag People */}
      {showTagPeople && (
        <div className="absolute right-0 top-full z-50 mt-2">
          <TagPeople onTagPeopleSelect={handleTagPeopleSelect} initialTags={taggedPeople} />
        </div>
      )}

      {/* Post Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Post Preview</DialogTitle>
            <DialogDescription>This is how your post will look when published.</DialogDescription>
          </DialogHeader>
          <PostPreview
            content={content}
            images={selectedImages}
            video={selectedVideo}
            gif={selectedGif}
            audio={selectedAudio}
            location={location}
            taggedPeople={taggedPeople}
            feeling={feeling}
            pollOptions={pollOptions.length > 0 ? { options: pollOptions, duration: pollDuration } : null}
            background={background}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPreview(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

