"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, MapPin, Loader2 } from "lucide-react"

interface LocationPickerProps {
  onLocationSelect: (location: string) => void
}

export function LocationPicker({ onLocationSelect }: LocationPickerProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [searchResults, setSearchResults] = useState<string[]>([])

  // Mock location data
  const mockLocations = [
    "San Francisco, CA",
    "New York, NY",
    "Los Angeles, CA",
    "Chicago, IL",
    "Seattle, WA",
    "Austin, TX",
    "Boston, MA",
    "Denver, CO",
  ]

  const handleSearch = () => {
    if (!searchQuery.trim()) return

    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      const results = mockLocations.filter((location) => location.toLowerCase().includes(searchQuery.toLowerCase()))
      setSearchResults(results)
      setIsLoading(false)
    }, 500)
  }

  return (
    <Card className="w-80">
      <CardHeader className="p-3">
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search locations"
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
          </div>
          <Button size="sm" onClick={handleSearch}>
            Search
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-3">
        {isLoading ? (
          <div className="flex h-40 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : searchResults.length > 0 ? (
          <div className="space-y-1">
            {searchResults.map((location, index) => (
              <button
                key={index}
                className="flex w-full items-center rounded-md px-2 py-1.5 text-sm hover:bg-muted"
                onClick={() => onLocationSelect(location)}
              >
                <MapPin className="mr-2 h-4 w-4 text-muted-foreground" />
                <span>{location}</span>
              </button>
            ))}
          </div>
        ) : (
          <div className="flex h-40 flex-col items-center justify-center space-y-2 text-center text-muted-foreground">
            <MapPin className="h-8 w-8" />
            <p>Search for a location to add to your post</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

