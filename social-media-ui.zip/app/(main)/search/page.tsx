import type { Metadata } from "next"
import { SearchPage } from "@/components/search/search-page"

export const metadata: Metadata = {
  title: "Search | SocialSphere",
  description: "Search for people, posts, and more on SocialSphere",
}

export default function Search() {
  return <SearchPage />
}

