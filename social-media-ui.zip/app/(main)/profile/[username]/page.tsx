import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { UserProfile } from "@/components/user/user-profile"
import { PostFeed } from "@/components/post/post-feed"
import { getUserProfile } from "@/lib/data"

interface ProfilePageProps {
  params: {
    username: string
  }
}

export async function generateMetadata({ params }: ProfilePageProps): Promise<Metadata> {
  const user = getUserProfile(params.username)

  if (!user) {
    return {
      title: "User Not Found | SocialSphere",
    }
  }

  return {
    title: `${user.name} (@${user.username}) | SocialSphere`,
    description: user.bio,
  }
}

export default function ProfilePage({ params }: ProfilePageProps) {
  const user = getUserProfile(params.username)

  if (!user) {
    notFound()
  }

  // In a real app, we would check if the current user is the profile owner
  // For demo purposes, we'll assume the current user is "johndoe"
  const isCurrentUser = params.username === "johndoe"

  return (
    <div className="space-y-6">
      <UserProfile user={user} isCurrentUser={isCurrentUser} />
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Posts</h2>
        <PostFeed username={params.username} isCurrentUser={isCurrentUser} />
      </div>
    </div>
  )
}

