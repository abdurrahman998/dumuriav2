import type { Metadata } from "next"
import { BookmarkList } from "@/components/bookmarks/bookmark-list"

export const metadata: Metadata = {
  title: "Bookmarks | SocialSphere",
  description: "Your saved posts on SocialSphere",
}

export default function BookmarksPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Bookmarks</h1>
      <BookmarkList />
    </div>
  )
}

