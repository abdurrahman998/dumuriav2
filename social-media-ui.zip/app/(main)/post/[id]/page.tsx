import type { Metadata } from "next"
import { notFound } from "next/navigation"
import { PostDetail } from "@/components/post/post-detail"
import { CommentSection } from "@/components/post/comment-section"
import { getPostById } from "@/lib/data"

interface PostPageProps {
  params: {
    id: string
  }
}

export async function generateMetadata({ params }: PostPageProps): Promise<Metadata> {
  const post = getPostById(params.id)

  if (!post) {
    return {
      title: "Post Not Found | SocialSphere",
    }
  }

  return {
    title: `${post.author.name}'s Post | SocialSphere`,
    description: post.content.substring(0, 160),
  }
}

export default function PostPage({ params }: PostPageProps) {
  const post = getPostById(params.id)

  if (!post) {
    notFound()
  }

  return (
    <div className="space-y-6">
      <PostDetail post={post} />
      <CommentSection postId={params.id} />
    </div>
  )
}

