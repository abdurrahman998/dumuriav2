// Mock search data and functions

import { users, posts } from "./data"

// Mock hashtags data
const hashtags = [
  {
    id: "hashtag-1",
    name: "#Technology",
    count: 1234,
    type: "hashtag",
  },
  {
    id: "hashtag-2",
    name: "#Design",
    count: 987,
    type: "hashtag",
  },
  {
    id: "hashtag-3",
    name: "#Programming",
    count: 876,
    type: "hashtag",
  },
  {
    id: "hashtag-4",
    name: "#AI",
    count: 765,
    type: "hashtag",
  },
  {
    id: "hashtag-5",
    name: "#WebDev",
    count: 654,
    type: "hashtag",
  },
  {
    id: "hashtag-6",
    name: "#UX",
    count: 543,
    type: "hashtag",
  },
  {
    id: "hashtag-7",
    name: "#UI",
    count: 432,
    type: "hashtag",
  },
  {
    id: "hashtag-8",
    name: "#JavaScript",
    count: 321,
    type: "hashtag",
  },
]

// Mock groups data
const groups = [
  {
    id: "group-1",
    name: "Tech Enthusiasts",
    description: "A group for tech lovers and enthusiasts",
    members: 1234,
    type: "group",
  },
  {
    id: "group-2",
    name: "Design Community",
    description: "Share and discuss design ideas and trends",
    members: 987,
    type: "group",
  },
  {
    id: "group-3",
    name: "Programmers Hub",
    description: "Connect with fellow programmers and developers",
    members: 876,
    type: "group",
  },
  {
    id: "group-4",
    name: "AI Researchers",
    description: "Discuss the latest in artificial intelligence",
    members: 765,
    type: "group",
  },
]

// Add type property to users and posts
const usersWithType = users.map((user) => ({ ...user, type: "user" }))
const postsWithType = posts.map((post) => ({ ...post, type: "post" }))

// Mock recent searches
let recentSearches: string[] = ["technology", "design", "programming", "artificial intelligence", "web development"]

// Mock trending searches
const trendingSearches = ["technology", "design", "programming", "AI", "WebDev", "UX", "UI", "JavaScript"]

// Fuzzy search function
function fuzzySearch(items: any[], query: string, keys: string[]) {
  const lowerQuery = query.toLowerCase()

  // Simple typo correction
  const corrections: Record<string, string> = {
    tecnology: "technology",
    programing: "programming",
    javascrpt: "javascript",
    artifical: "artificial",
    inteligence: "intelligence",
    develoment: "development",
  }

  // Check if query has a common typo and correct it
  for (const [typo, correction] of Object.entries(corrections)) {
    if (lowerQuery.includes(typo)) {
      const correctedQuery = lowerQuery.replace(typo, correction)
      return fuzzySearch(items, correctedQuery, keys)
    }
  }

  return items.filter((item) => {
    return keys.some((key) => {
      const value = key.split(".").reduce((obj, k) => obj && obj[k], item)
      return value && value.toString().toLowerCase().includes(lowerQuery)
    })
  })
}

// Perform search
export async function performSearch(query: string, category = "all") {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const results: {
    users: any[]
    posts: any[]
    hashtags: any[]
    groups: any[]
  } = {
    users: [],
    posts: [],
    hashtags: [],
    groups: [],
  }

  if (category === "all" || category === "users") {
    results.users = fuzzySearch(usersWithType, query, ["name", "username", "bio"])
  }

  if (category === "all" || category === "posts") {
    results.posts = fuzzySearch(postsWithType, query, ["content", "author.name", "author.username"])
  }

  if (category === "all" || category === "hashtags") {
    results.hashtags = fuzzySearch(hashtags, query, ["name"])
  }

  if (category === "all" || category === "groups") {
    results.groups = fuzzySearch(groups, query, ["name", "description"])
  }

  return results
}

// Get search suggestions
export async function getSuggestions(query: string) {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 300))

  if (!query) return []

  const userResults = fuzzySearch(usersWithType, query, ["name", "username"]).slice(0, 3)
  const hashtagResults = fuzzySearch(hashtags, query, ["name"]).slice(0, 3)
  const postResults = fuzzySearch(postsWithType, query, ["content"]).slice(0, 3)
  const groupResults = fuzzySearch(groups, query, ["name"]).slice(0, 3)

  return [...userResults, ...hashtagResults, ...postResults, ...groupResults]
}

// Get recent searches
export async function getRecentSearches() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 200))

  return recentSearches
}

// Get trending searches
export async function getTrendingSearches() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 200))

  return trendingSearches.map((tag) => ({
    id: `trending-${tag}`,
    name: tag,
    count: Math.floor(Math.random() * 1000) + 100,
  }))
}

// Add search to recent searches
export function addToRecentSearches(query: string) {
  if (!recentSearches.includes(query)) {
    recentSearches = [query, ...recentSearches.slice(0, 9)]
  }

  return recentSearches
}

// Clear recent searches
export function clearRecentSearches() {
  recentSearches = []
  return recentSearches
}

// Clear specific recent search
export function clearRecentSearch(query: string) {
  recentSearches = recentSearches.filter((search) => search !== query)
  return recentSearches
}

